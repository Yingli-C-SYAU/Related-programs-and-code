classdef artmo_netcdf
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        path
        ncid
        ndims
        nvars
        ngatts
        unlimdimid
        estado=true
    end
    
    methods
        function this=artmo_netcdf(path_,option,borrar)
            if nargin>=1
                this.path=path_;
                if exist(path_,'file')>=2
                    if nargin==3
                        if borrar
                            delete(path_)
                            if ~isempty(option)
                                flag=option;
                            else
                                %flag=bitor(netcdf.getConstant('SHARE'),bitor(netcdf.getConstant('NETCDF4'),netcdf.getConstant('CLOBBER')));
                                flag=netcdf.getConstant('NETCDF4');
                            end
                            
                            this.ncid = netcdf.create(path_,flag);
                        else
                            this.estado=true;
                            this=this.openR;
                        end
                    else
                        this.estado=true;
                        this=this.openR;
                    end
                else
                    if nargin>1
                        if ~isempty(option)
                            flag=option;
                        else
                            %flag='NETCDF4';
                            %flag=bitor(netcdf.getConstant('SHARE'),bitor(netcdf.getConstant('NETCDF4'),netcdf.getConstant('CLOBBER')));
                            flag=netcdf.getConstant('NETCDF4');
                        end
                    else
                        %flag='NETCDF4';
                        %flag=bitor(netcdf.getConstant('SHARE'),bitor(netcdf.getConstant('NETCDF4'),netcdf.getConstant('CLOBBER')));
                        flag=netcdf.getConstant('NETCDF4');
                    end
                    this.ncid = netcdf.create(path_,flag);
                end
            end
        end
        function this=create(this,path_,option)
            if nargin==3
                flag=option;
            else
                %flag='NETCDF4';
                %flag=bitor(netcdf.getConstant('SHARE'),bitor(netcdf.getConstant('NETCDF4'),netcdf.getConstant('CLOBBER')));
                flag=netcdf.getConstant('NETCDF4');
            end
            this.ncid = netcdf.create(path_,flag);
            this.path=path_;
            
        end
        function iddim=add_dim(this,var_)
            for item=var_'
                if isinf(item{2,1})
                    dim=netcdf.getConstant('NC_UNLIMITED');
                else
                    dim=item{2,1};
                end
                iddim=netcdf.defDim(this.ncid,item{1,1},dim);
            end
        end
        
        function idvar=add_var(this,var_,cores_)
            if nargin<3
                cores_=1;
            end
            
            %var_ cell(nx3)
            %col1=name
            %col2=type
            %col3=[id_dims]
            
            for item=var_'
                idvar=netcdf.defVar(this.ncid,item{1,1},item{2,1},item{3,1});
                tamano=item{3,1};
                for i=1:length(item{3,1})
                    dimid=item{3,1}(i);
                    [~, tamano(i)] = netcdf.inqDim(this.ncid,dimid);
                end
                tamano(tamano~=max(tamano))=1;
                %tamano=fix(tamano./cores_);
                %tamano(tamano==0)=1;
                %netcdf.defVarChunking(this.ncid,idvar,'CHUNKED',tamano);
            end
        end
        function idvar=add_var1(this,var_,cores_)
            if nargin<3
                cores_=1;
            end
            %var_ cell(nx3)
            %col1=name
            %col2=type
            %col3=[id_dims]
            
            for item=var_'
                idvar=netcdf.defVar(this.ncid,item{1,1},item{2,1},item{3,1});
                tamano=item{3,1};
                for i=1:length(item{3,1})
                    dimid=item{3,1}(i);
                    [~, tamano(i)] = netcdf.inqDim(this.ncid,dimid);
                end
                
                netcdf.indepenJP(this.ncid,idvar)
                tamano(tamano~=max(tamano))=1;
                %tamano=fix(tamano./cores_);
                %tamano(tamano==0)=1;
                %netcdf.defVarChunking(this.ncid,idvar,'CHUNKED',tamano);
            end
        end
        function idvar=add_var_out(this,var_,cores_)
            %var_ cell(nx3)
            %col1=name
            %col2=type
            %col3=[id_dims]
            
            for item=var_'
                idvar=netcdf.defVar(this.ncid,item{1,1},item{2,1},item{3,1});
                tamano=item{3,1};
                for i=1:length(item{3,1})
                    dimid=item{3,1}(i);
                    [~, tamano(i)] = netcdf.inqDim(this.ncid,dimid);
                end
                tamano(tamano~=max(tamano))=1;
                %tamano=fix(tamano./cores_);
                %tamano(tamano==0)=1;
                %netcdf.defVarChunking(this.ncid,idvar,'CHUNKED',tamano);
                netcdf.putAtt(this.ncid,idvar,'Units',item{4,1})
                
                
            end
        end
        function idvar=add_var_out1(this,var_,cores_)
            %var_ cell(nx3)
            %col1=name
            %col2=type
            %col3=[id_dims]
            
            for item=var_'
                idvar=netcdf.defVar(this.ncid,item{1,1},item{2,1},item{3,1});
                tamano=item{3,1};
                for i=1:length(item{3,1})
                    dimid=item{3,1}(i);
                    [~, tamano(i)] = netcdf.inqDim(this.ncid,dimid);
                end
                tamano(tamano~=max(tamano))=1;
                %tamano=fix(tamano./cores_);
                %tamano(tamano==0)=1;
                %netcdf.defVarChunking(this.ncid,idvar,'CHUNKED',tamano);
                %keyboard
                netcdf.indepenJP(this.ncid,idvar)
                netcdf.putAtt(this.ncid,idvar,'Units',item{4,1})
            end
        end
        function this=openW(this)
            if this.estado
                flag=netcdf.getConstant('NC_WRITE');
                this.ncid=netcdf.open(this.path,flag);
            end
            %this=this.info;
        end
        function this=openR(this)
            if this.estado
                flag=netcdf.getConstant('NC_NOWRITE');
                this.ncid=netcdf.open(this.path,flag);
            end
            %this=this.info;
        end
        function this=close(this)
            if this.estado
                netcdf.close(this.ncid);
                this.ncid=[];
            end
        end
        function this=info(this)
            [ndims_,nvars_,this.ngatts,this.unlimdimid] = netcdf.inq(this.ncid);
            this.ndims=cell(ndims_,3);
            for i=1:ndims_
                this.ndims{i,1}=i-1;
                [this.ndims{i,2},this.ndims{i,3}]=netcdf.inqDim(this.ncid,i-1);
            end
            this.nvars=cell(nvars_,5);
            for i=1:nvars_
                this.nvars{i,1}=i-1;
                [this.nvars{i,2},this.nvars{i,3},this.nvars{i,5},~]=netcdf.inqVar(this.ncid,i-1);
                this.nvars(i,4)=this.nvars(i,2);
            end
        end
        function data=readvar(this,varname)
            this=this.openR;
            varid = netcdf.inqVarID(this.ncid,varname);
            data = netcdf.getVar(this.ncid,varid);
            this.close;
        end
    end
    
    
end