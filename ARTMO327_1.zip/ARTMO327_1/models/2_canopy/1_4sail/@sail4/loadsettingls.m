function this=loadsettingls(this,settings)

tabla=settings.inputs(settings.inputs(:,),:);
end