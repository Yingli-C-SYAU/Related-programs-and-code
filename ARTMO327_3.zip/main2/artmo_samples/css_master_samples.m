classdef css_master_samples
    %UNTITLED3 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        path_gui
        filesep_
        pathnc
    end
    properties
        type_sample
    end
    methods
        function this=css_master_samples
            tmp=mfilename('fullpath');
            this.filesep_=filesep;
            dummy01=strfind(tmp,this.filesep_);
            this.path_gui=[tmp(1:dummy01(end)) 'guis' this.filesep_];
            this.pathnc=[tmp(1:dummy01(end)) 'temp' this.filesep_ ['datasamples_' datestr(now,30) '.nc']];
        end
        function this=make_samples_nc(this,num,var1)
            dummycdf=artmo_netcdf(this.pathnc);
            dim1=dummycdf.add_dim({'sim' num});
            var1=struct('id',{},'distri',{},'value',{},'name',{});
            for item=fieldnames(this.variables.(class_).datos)'
                for item1=fieldnames(this.variables.(class_).datos.(item{1}).data)'
                    if isfield(this.variables.(class_).datos.(item{1}).data.(item1{1}),'distr')
                        i=i+1;
                        
                        var1(i).id=dummycdf.add_var({[this.artmo_varglobal '_' item1{1}]  'NC_DOUBLE' dim1});
                        netcdf.putAtt(dummycdf.ncid,var1(i).id,'model',this.artmo_name)
                        var1(i).distri=this.variables.(class_).datos.(item{1}).data.(item1{1}).distr;
                        var1(i).distri.samples_=num;
                        var1(i).name=item1{1};
                    end
                end
            end
            switch this.type_sample
                case 'LHS'
                    X = lhsdesign(num,length(var1));
                    ncid1 = netcdf.open(this.pathnc,'NC_WRITE');
                    for i=1:length(var1)
                        
                        param=var1(i).distri.min1+X(:,i)*(var1(i).distri.max1-var1(i).distri.min1);
                        netcdf.putVar(ncid1,var1(i).id,param);
                    end
                    netcdf.close(ncid1)
                otherwise
                    ncid1 = netcdf.open(this.pathnc,'NC_WRITE');
                    for i=1:length(var1)
                        netcdf.putVar(ncid1,var1(i).id,double(var1(i).distri.make_sample));
                    end
                    netcdf.close(ncid1)
            end
        end
        function this=makenetcdf(this,class_,num,this2)
            global gb_artmo
            if exist(fullfile(gb_artmo.cd1,[this.artmo_varglobal '.nc']),'file')==2
                delete(fullfile(gb_artmo.cd1,[this.artmo_varglobal '.nc']));
            end
            this.pathnc=fullfile(gb_artmo.cd1,[this.artmo_varglobal '.nc']);
            dummycdf=artmo_netcdf(this.pathnc);
            i=0;
            dim1=dummycdf.add_dim({'sim' num});
            var1=struct('id',{},'distri',{},'value',{},'name',{});
            for item=fieldnames(this.variables.(class_).datos)'
                for item1=fieldnames(this.variables.(class_).datos.(item{1}).data)'
                    if isfield(this.variables.(class_).datos.(item{1}).data.(item1{1}),'distr')
                        i=i+1;
                        
                        var1(i).id=dummycdf.add_var({[this.artmo_varglobal '_' item1{1}]  'NC_DOUBLE' dim1});
                        netcdf.putAtt(dummycdf.ncid,var1(i).id,'model',this.artmo_name)
                        var1(i).distri=this.variables.(class_).datos.(item{1}).data.(item1{1}).distr;
                        var1(i).distri.samples_=num;
                        var1(i).name=item1{1};
                    end
                end
            end
            if nargin==4
                for item=fieldnames(this2.datos)'
                    for item1=fieldnames(this2.datos.(item{1}).data)'
                        if isfield(this2.datos.(item{1}).data.(item1{1}),'distr')
                            i=i+1;
                            var1(i).id=dummycdf.add_var({[ this2.idmodel '_' item1{1}]  'NC_DOUBLE' dim1});
                            netcdf.putAtt(dummycdf.ncid,var1(i).id,'model',this2.model)
                            var1(i).distri=this2.datos.(item{1}).data.(item1{1}).distr;
                            var1(i).distri.samples_=num;
                            var1(i).name=item1{1};
                        end
                    end
                end
            end
            this.numvarnc=i-1;
            dummycdf.close;
            
            rng(gb_artmo.seed,'twister');
            try
                switch this.type_sample
                    case 'LHS'
                        X = lhsdesign(num,length(var1));
                        ncid1 = netcdf.open(this.pathnc,'NC_WRITE');
                        for i=1:length(var1)
                            
                            param=var1(i).distri.min1+X(:,i)*(var1(i).distri.max1-var1(i).distri.min1);
                            netcdf.putVar(ncid1,var1(i).id,param);
                        end
                        netcdf.close(ncid1)                    
                    otherwise
                        ncid1 = netcdf.open(this.pathnc,'NC_WRITE');
                        for i=1:length(var1)
                            netcdf.putVar(ncid1,var1(i).id,double(var1(i).distri.make_sample));
                        end
                        netcdf.close(ncid1)
                end
            catch ME
                rethrow(ME)
                netcdf.close(ncid1)                
            end
            
        end
    end
    
end

