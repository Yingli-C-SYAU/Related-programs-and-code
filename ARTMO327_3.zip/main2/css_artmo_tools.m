classdef css_artmo
    properties (Constant=true,Hidden=true)
        %uso global de todas las funciones
        mac_all={'00-1F-D0-8F-FD-52';'A4-BA-DB-A8-8D-24';'00-24-D6-51-B1-34';'50-E5-49-E7-C0-E7'};
    end
    
    properties (Access=protected,Hidden=true)
        control=true
    end
    properties
        listmodels={}
        varmodels={}
        varmodels1={}
        varmodels2={}
        outmodels={}
        WLoutmodels={}
        listmodels_aux={}
        smth=false;
        pct=true;
    end
    properties(Hidden)
        pct_obj    
        controlwl=false;
        num_line_image=100;
    end
    methods
        function this=css_artmo
            
            persistent control
            if isempty(control)
                control=false;
                dummu=ver;
                for i=1:length(dummu)
                    if strcmpi(dummu(i).Name,'Neural Network Toolbox')
                        control=true;
                        break
                    end
                end                
            end
            if control                
                this.pct_obj=pct_artmo;
            end
        end
    end
    methods (Access=protected,Hidden=true)
        function this=revisar(this,mac_module)
            try
                fid=fopen('key_artmo.access','r');
                mac_usser=char(fread(fid,inf,'uint16')./2)';
                fclose(fid);
                ok_max=[mac_module;this.mac_all];
                if ~any(strcmpi(mac_usser,ok_max))
                    this.control=false;
                    %delete('key_artmo.access');
                    %error('ARTMO:ErrorKey','ARTMO not find the file key.access. Please contact with artmo@uv.es')
                else
                    this.control=true;
                end
            catch exception
                throw(MException('ARTMO:ErrorKey', char(exception.message)));
            end
        end
        function this=load_models(this)            
            [cd1, ~, ~]=fileparts(mfilename('fullpath'));
            k=strfind(cd1,filesep);
            cd1(k(end):end)=[];
            lista=dir(fullfile(cd1,'models'));
            if isempty(lista)
                return
            end
            for v_dir=lista'
                if  ~strcmpi(v_dir.name,{'.' '..'})
                    lista1=dir(fullfile(cd1,'models',v_dir.name));
                    for v_dir1=lista1'
                        if  ~strcmpi(v_dir1.name,{'.' '..'})
                            lista2=dir(fullfile(cd1,'models',v_dir.name,v_dir1.name));
                            for v_dir3=lista2'
                                if v_dir3.isdir
                                    if  ~strcmpi(v_dir3.name,{'.' '..'})
                                        tmp=strfind(v_dir3.name,'@');
                                        if any(tmp)
                                            %crea item1
                                            objeto=v_dir3.name(tmp(1)+1:end);
                                            eval(['import ' objeto '.*'])
                                            eval(['temp = ' objeto ';'])
                                            this=this.sg_models(temp);
                                            this=this.sg_models1(temp);
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            
            lista=unique(this.varmodels(:,end));
            control2=false(size(this.listmodels,1),1);
            for item=1:size(this.listmodels,1)
                control1=false(numel(this.listmodels{item,2}),1);
                for item1=1:numel(this.listmodels{item,2})
                    if any(strcmpi(this.listmodels{item,2}{item1},lista))
                        control1(item1)=true;
                    end
                end
                if all(control1)
                    control2(item)=true;
                end
            end
            this.listmodels=this.listmodels(control2,:);
        end
        function this=load_emulador(this)
            
            [cd1, ~, ~]=fileparts(mfilename('fullpath'));
            k=strfind(cd1,filesep);
            cd1(k(end):end)=[];
            lista=dir(fullfile(cd1,'modules'));
            if isempty(lista)
                return
            end
            for v_dir=lista'
                if  exist(fullfile(cd1,'modules',v_dir.name,'@css_mod_emulator'),'dir')==7
                    this.listmodels_aux={'Emulator' []};
                end
            end
        end
        function this=load_models_sgm(this)
            [cd1, ~, ~]=fileparts(mfilename('fullpath'));
            k=strfind(cd1,filesep);
            cd1(k(end):end)=[];
            lista=dir(fullfile(cd1,'models'));
            if isempty(lista)
                return
            end
            for v_dir=lista'
                if  ~strcmpi(v_dir.name,{'.' '..'})
                    lista1=dir(fullfile(cd1,'models',v_dir.name));
                    for v_dir1=lista1'
                        if  ~strcmpi(v_dir1.name,{'.' '..'})
                            lista2=dir(fullfile(cd1,'models',v_dir.name,v_dir1.name));
                            for v_dir3=lista2'
                                if v_dir3.isdir
                                    if  ~strcmpi(v_dir3.name,{'.' '..'})
                                        tmp=strfind(v_dir3.name,'@');
                                        if any(tmp)
                                            %crea item1
                                            objeto=v_dir3.name(tmp(1)+1:end);
                                            eval(['import ' objeto '.*'])
                                            eval(['temp = ' objeto ';'])
                                            
                                            this=this.sg_models(temp);
                                            this=this.sg_models1(temp);
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            
            lista=unique(this.varmodels(:,end));
            control2=false(size(this.listmodels,1),1);
            for item=1:size(this.listmodels,1)
                control1=false(numel(this.listmodels{item,2}),1);
                for item1=1:numel(this.listmodels{item,2})
                    if any(strcmpi(this.listmodels{item,2}{item1},lista))
                        control1(item1)=true;
                    end
                end
                if all(control1)
                    control2(item)=true;
                end
            end
            this.listmodels=this.listmodels(control2,:);
        end
        function this=sg_models(this,model)
            global gb_artmo
            p=methods(model);            
            if any(strcmpi(p,'sensibity'))                
                tablatmp=model.metainput(:,[6 4 7 3 8 1 9 5]);
                tablatmp(cell2mat(tablatmp(:,2))==1,:)=[];
                tablatmp(:,end+1)={model.artmo_name};
                this.varmodels=[this.varmodels;tablatmp];
                tablatmp=model.metainput(:,[6 4 7 3 8 1 9 5]);
                tablatmp(:,end+1)={model.artmo_name};
                this.varmodels2=[this.varmodels2;tablatmp];
                tablatmp=model.metaoutput(:,[1 3 4 5 10 9]);
                tablatmp(:,end+1)={model.artmo_name};
                tablatmp(cell2mat(tablatmp(:,4))==0,:)=[];
                this.outmodels=[this.outmodels;tablatmp];
                if ~isempty(model.artmo_union)                   
                    for item=model.artmo_union'
                        indx=strcmpi(item{1},gb_artmo.modelos(:,2));
                        if any(indx)
                            tmp=gb_artmo.modelos{strcmpi( item{1},gb_artmo.modelos(:,2)),5};
                            eval(['global ' tmp])
                            eval(['p1=methods(' tmp ');'])
                            if any(strcmpi(p1,'sensibity'))
                                this.listmodels(end+1,1)={[model.artmo_name '-' item{1}]};
                                this.listmodels{end,2}=[{model.artmo_name} item(1)];
                            end
                        end
                    end
                else
                    this.listmodels(end+1,1)={model.artmo_name};
                    this.listmodels(end,2)={{model.artmo_name}};
                end
            end
        end
        function this=models_sgm(this,model)
            global gb_artmo
            p=methods(model);
            if any(strcmpi(p,'SGM_options'))
                
                tablatmp=model.metainput(:,[6 4 7 3 8 1 9 5]);
                tablatmp(cell2mat(tablatmp(:,2))==1,:)=[];
                tablatmp(:,end+1)={model.artmo_name};
                this.varmodels_sgm=[this.varmodels;tablatmp];
                tablatmp=model.metainput(:,[6 4 7 3 8 1 9 5]);
                tablatmp(:,end+1)={model.artmo_name};
                this.varmodels2_sgm=[this.varmodels2;tablatmp];
                tablatmp=model.metaoutput(:,[1 3 4 5 10 9]);
                tablatmp(:,end+1)={model.artmo_name};
                tablatmp(cell2mat(tablatmp(:,4))==0,:)=[];
                this.outmodels_sgm=[this.outmodels;tablatmp];
                if ~isempty(model.artmo_union)
                    for item=model.artmo_union'
                        tmp=gb_artmo.modelos{strcmpi( item{1},gb_artmo.modelos(:,2)),5};
                        eval(['global ' tmp])
                        eval(['p1=methods(' tmp ');'])
                        if any(strcmpi(p1,'sensibity'))
                            this.listmodels_sgm(end+1,1)={[model.artmo_name '-' item{1}]};
                            this.listmodels_sgm{end,2}=[{model.artmo_name} item(1)];
                        end
                    end
                else
                    this.listmodels_sgm(end+1,1)={model.artmo_name};
                    this.listmodels_sgm(end,2)={{model.artmo_name}};
                end
            end
        end
        function this=sg_models1(this,model)
            p=properties(model);
            if any(strcmpi(p,'sg1'))
                tablatmp=model.sg1;
                tablatmp(:,end+1)={model.artmo_name};
                this.varmodels1=[this.varmodels1;tablatmp];
            end
        end
    end
end

