clear
clc

x = xlsread('pso_chl_adan.xls');
c = x(:,6);
test = c(166:196,:);
samples = c(1:165,:);

[maxc,minc,meanc,stdc,cvc] = stactic_chl(c);
[maxs,mins,means,stds,cvs] = stactic_chl(samples);
[maxt,mint,meant,stdt,cvt] = stactic_chl(test);
Data = [[maxc,minc,meanc,stdc,cvc];[maxs,mins,means,stds,cvs];[maxt,mint,meant,stdt,cvt]];
