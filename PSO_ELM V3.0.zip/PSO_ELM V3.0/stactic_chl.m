function [maxc,minc,meanc,stdc,cvc] = stactic_chl(c)

    maxc = max(c);
    minc = min(c);
    meanc = mean(c);
    stdc = std(c);
    cvc = stdc/meanc;
end